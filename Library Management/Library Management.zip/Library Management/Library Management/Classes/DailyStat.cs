﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Library_Management.Classes
{
    public class DailyStat
    {
        public string DateLabel { get; set; }
        public int Count { get; set; }
    }
}